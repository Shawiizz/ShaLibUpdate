<?php
function getDirContents($path) {
    $rii = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path));

    $files = array();
    foreach ($rii as $file)
        if (!$file->isDir() && $file != "./index.php")
            $files[] = $file->getPathname();

    return $files;
}

foreach (getDirContents('.') as $key => $value) {
  echo $value,"|",md5_file($value),"\n";
}
?>
