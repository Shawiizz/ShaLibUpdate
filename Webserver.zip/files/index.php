<?php
function ScanDirectory($Directory, $tableau = false)
{
    $slash = '';
    $MyDirectory = opendir($Directory) or die('Erreur');
    while ($Entry = @readdir($MyDirectory)) {
        if ($Entry != '.' && $Entry != '..' && $Entry != 'index.php' && $Entry != ".htaccess" && !is_dir($Entry))
            $tableau[] = substr($Directory . '/' . $Entry, strlen(strstr($Directory . '/' . $Entry, '/', true)) + 1) . $slash;
        if (is_dir($Directory . '/' . $Entry) && $Entry != '.' && $Entry != '..')
            $tableau = ScanDirectory($Directory . '/' . $Entry, $tableau);
    }
    closedir($MyDirectory);
    return $tableau;
}

foreach (ScanDirectory('.') as $key => $value) {
  if(!is_dir($value))
    echo $value,"|",md5_file($value),"\n";
}
?>
